<?php
class app_LiderResultado_lookup
{
}
?>
