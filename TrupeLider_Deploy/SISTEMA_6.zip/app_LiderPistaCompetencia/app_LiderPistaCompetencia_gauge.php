<HTML>
<HEAD>
 <TITLE>app_LiderPistaCompetencia :: PDF</TITLE>
 <META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
 <META http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT">
 <META http-equiv="Last-Modified" content="<?php echo gmdate('D, d M Y H:i:s'); ?> GMT">
 <META http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
 <META http-equiv="Cache-Control" content="post-check=0, pre-check=0">
 <META http-equiv="Pragma" content="no-cache">
 <SCRIPT LANGUAGE="Javascript" SRC="<?php echo urldecode($_GET['jspath']); ?>/nm_gauge.js"></SCRIPT>
</HEAD>
<BODY bgcolor="<?php echo urldecode($_GET['sc_apbgcol']); ?>" leftmargin="0" rightmargin="0" topmargin="0" bottommargin="0" marginwidth="0" marginheight="0">
<TABLE border="0" cellpadding="0" cellspacing="0" height="100%" width="100%"><TR><TD align="center" valign="middle">
<script language="Javascript">
var pb = new nmGauge('app_LiderPistaCompetencia', 'PDF', 300, 'Gerando PDF');
</script>
</TD></TR></TABLE>
</BODY>
</HTML>
