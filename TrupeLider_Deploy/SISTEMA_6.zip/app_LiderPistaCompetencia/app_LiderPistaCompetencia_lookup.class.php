<?php
class app_LiderPistaCompetencia_lookup
{
}
?>
