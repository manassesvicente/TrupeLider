<?php
class app_GrupoCompetencia_lookup
{
}
?>
