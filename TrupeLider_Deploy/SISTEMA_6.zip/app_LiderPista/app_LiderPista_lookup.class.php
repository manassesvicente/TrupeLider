<?php
class app_LiderPista_lookup
{
}
?>
