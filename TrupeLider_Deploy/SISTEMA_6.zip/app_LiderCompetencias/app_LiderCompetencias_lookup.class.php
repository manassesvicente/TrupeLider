<?php
class app_LiderCompetencias_lookup
{
}
?>
